
const express = require('express');
const cors = require('cors');
const {MongoClient} = require('mongodb');
const router = express.Router()
const app = express();
app.use(cors())
app.use(express.json())

const uri = "mongodb+srv://admin:admin@cluster0.efsy7fg.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(uri);
const db = client.db("MarksManagementSystem");
const col = db.collection("user");

router.post('/login',async (req,res)=>{
    const saltpwd = await bcrypt.genSalt(10);
    const securepassword = await bcrypt.hash(req.body.password,saltpwd);
    const signupuser = new signuptemp({
        fullname:req.body.fullname,
        email:req.body.email,
        password:securepassword
    })
    signupuser.save()
    .then(data=>{
        res.json(data);
    })
    .catch(e=>{
        res.json(e);
    })
});

app.get('/products',async (req,res) => {
    const result = await col.find().toArray();
    console.log(result);
    res.send(result);
})

app.delete('/delete/:id',async (req,res) => {
    const id = req.params.id;
    const result = await col.deleteOne({pid : id});
    console.log(result);
    res.send(result);
})

// app.get('/',(req,res)=>{
//     console.log('This is Get Request')
// })

app.use(express.json())
app.use(cors());
app.use('/api',routesurls);
app.listen(2000,()=>{console.log("Server Started on 2000")})